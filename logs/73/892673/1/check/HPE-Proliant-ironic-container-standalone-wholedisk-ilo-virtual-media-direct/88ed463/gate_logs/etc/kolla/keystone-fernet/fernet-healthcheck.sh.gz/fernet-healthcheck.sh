#!/bin/bash

set -o errexit
set -o pipefail

(/usr/bin/fernet-node-sync.sh --check && /usr/bin/fernet-push.sh --check) || exit 1
